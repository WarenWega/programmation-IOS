//
//  model.swift
//  TpToDoList
//
//  Created by Anïck Ryane Mouafo Mawetze on 23/11/2022.
//

import Foundation

class Todo{
    var nom: String
    var desc: String
    
    init(nom: String, desc: String) {
        self.nom = nom
        self.desc = desc
    }
}

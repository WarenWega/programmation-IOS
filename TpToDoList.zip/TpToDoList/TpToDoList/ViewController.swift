//
//  ViewController.swift
//  TpToDoList
//
//  Created by Anïck Ryane Mouafo Mawetze on 09/11/2022.
//

import UIKit

class ViewController: UIViewController{
    
    @IBOutlet weak var myTableView: UITableView!
    /*var myData = [Todo]()
    // Return the number of rows for the table.
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myData.count
    }

    // Provide a cell object for each row.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       // Fetch a cell of the appropriate type.
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellTypeIdentifier", for: indexPath) as! toDoTableViewCell
       
       // Configure the cell’s contents.
        //cell.textLabel!.text = "Cell text"
        cell.titre.text = "Cell text"
       return cell
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //fournir un contenu pour chaque cellules de la ligne
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! myTabelViewCellTableViewCell
        
        
        cell.myLabel.text = myData[indexPath.row].desc
        cell.myImage.image = UIImage(named: String(myData[indexPath.row].img))
        return cell
    }*/
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    
}


//
//  ViewController.swift
//  TpToDoList
//
//  Created by Anïck Ryane Mouafo Mawetze on 09/11/2022.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        data.count
    }
    //récupère une cellule et la peuple de diff elements
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "ToDocell", for: indexPath) as! toDoTableViewCell
        
        
        cell.titre.text = data[indexPath.row].nom
        //cell.Description.text = data[indexPath.row].desc
        cell.statut.isOn = data[indexPath.row].stat
        
        return cell
    }
    
    
    @IBOutlet weak var myTableView: UITableView!
    var data : [Todo] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
            let nom = "faire les courses"
            let desc = "lait oeuf"
            let stat = false
            let d = Todo(nom: nom, desc: desc, stat: stat)
            data.append(d)
        
        for _ in 2...3{
            let nom = "faire du sport"
            let desc = "gym d'entretien"
            let stat = false
            let d = Todo(nom: nom, desc: desc, stat: stat)
            data.append(d)
        }
        myTableView.dataSource = self
        
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let viewcontroller = segue.destination as?  TachesViewController  { let row = myTableView.indexPathForSelectedRow?.row
            viewcontroller.data = data[row!]
        }
    }
    
    @IBAction func add(_ unwindSegue: UIStoryboardSegue) {
        // Use data from the view controller which initiated the unwind segue
        if let viewcontroller = unwindSegue.source as? AddViewController {
            if let newTodo = viewcontroller.data {
                data.append(newTodo)
                myTableView.reloadData()
            }
            else {
                print("if 2")
            }
        }
        else {
            print("if 1")
        }
        
    }
}

